"""Template for answers to be submitted as Part 1 of HW6, CPSC 3400, Spring 2021
ONLY change the string constants below and hand in this file after RENAMING it
to hw6.py. You can use (and modify) hw6_test.py to test your submission. Do NOT
hand in hw6_template.py or hw6_test.py.
"""

a = r'Your regular expression here for problem 1.a.'  # FIXME
b = r'Your regular expression here for problem 1.b.'  # FIXME
c = r'Your regular expression here for problem 1.c.'  # FIXME
d = r'Your regular expression here for problem 1.d.'  # FIXME
d_sub = r'Your substitution string here for problem 1.d'  # FIXME

